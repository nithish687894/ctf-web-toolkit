#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════╗
║              CTF API FUZZER v3.0 — Elite Edition                ║
║  Comprehensive API Endpoint Discovery & HTTP Method Enumeration ║
║  For: International CTF Competitions (Web Challenges)           ║
╚══════════════════════════════════════════════════════════════════╝

Features:
  • Smart endpoint discovery with recursive depth crawling
  • All HTTP method testing (GET/POST/PUT/DELETE/PATCH/OPTIONS/HEAD/TRACE)
  • Built-in CTF-optimized wordlists (admin, debug, flag, backup, etc.)
  • Custom wordlist support
  • Response fingerprinting & anomaly detection
  • JSON/XML/GraphQL endpoint detection
  • Hidden parameter discovery in responses
  • Rate limiting & threading control
  • Color-coded output with export (JSON/CSV/TXT)
  • Auto-detection of frameworks (Flask, Express, Django, Spring, etc.)
  • Cookie/Token/Header injection support
  • WAF detection & evasion hints

Usage:
  python3 ctf_api_fuzzer.py -u http://target.com --smart --depth 2
  python3 ctf_api_fuzzer.py -u http://target.com --methods --depth 3 --threads 20
  python3 ctf_api_fuzzer.py -u http://target.com -w custom_wordlist.txt --headers "Authorization: Bearer TOKEN"
  python3 ctf_api_fuzzer.py -u http://target.com --graphql --full-scan -o results.json
"""

import argparse
import sys
import json
import csv
import time
import re
import itertools
import concurrent.futures
from urllib.parse import urljoin, urlparse, parse_qs
from collections import defaultdict
from datetime import datetime

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:
    print("[!] requests library required: pip install requests")
    sys.exit(1)

# ─── ANSI Colors ───────────────────────────────────────────────────
class C:
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"

def banner():
    print(f"""{C.CYAN}{C.BOLD}
    ╔══════════════════════════════════════════════════════╗
    ║         ⚡ CTF API FUZZER v3.0 — Elite ⚡           ║
    ║      Endpoint Discovery · Method Enumeration        ║
    ║          Framework Detection · Vuln Hints           ║
    ╚══════════════════════════════════════════════════════╝{C.RESET}
    """)

# ─── CTF-Optimized Wordlists ──────────────────────────────────────
CTF_ENDPOINTS = {
    "common_api": [
        "api", "api/v1", "api/v2", "api/v3", "api/v4",
        "v1", "v2", "v3", "rest", "graphql", "gql",
        "api/graphql", "api/rest", "api/internal", "api/private",
        "api/public", "api/external", "api/mobile", "api/app",
    ],
    "auth_endpoints": [
        "login", "logout", "register", "signup", "signin",
        "auth", "authenticate", "authorize", "oauth", "oauth2",
        "token", "refresh", "session", "sessions", "sso",
        "api/login", "api/auth", "api/token", "api/register",
        "api/v1/login", "api/v1/auth", "api/v1/token",
        "api/v1/register", "api/v1/users/login",
        "auth/login", "auth/register", "auth/token",
        "auth/callback", "auth/verify", "auth/reset",
        "password/reset", "password/forgot", "password/change",
        "2fa", "mfa", "otp", "verify", "confirm",
    ],
    "user_endpoints": [
        "users", "user", "profile", "profiles", "account",
        "accounts", "me", "self", "whoami", "identity",
        "api/users", "api/user", "api/profile", "api/me",
        "api/v1/users", "api/v1/user", "api/v1/profile",
        "api/v1/me", "api/v1/accounts",
        "users/me", "users/self", "users/current",
        "users/admin", "users/1", "users/0", "users/2",
        "members", "staff", "employees", "people",
    ],
    "admin_debug": [
        "admin", "administrator", "admin/login", "admin/panel",
        "admin/dashboard", "admin/config", "admin/settings",
        "admin/users", "admin/flags", "admin/console",
        "dashboard", "panel", "console", "management",
        "debug", "debug/vars", "debug/pprof", "debug/routes",
        "debug/config", "debug/info", "debug/log",
        "internal", "internal/api", "internal/config",
        "internal/status", "internal/health",
        "devtools", "dev", "development", "test", "testing",
        "staging", "sandbox", "beta", "alpha",
        "_debug", "_admin", "_internal", "_config",
        "__debug__", "__admin__",
    ],
    "ctf_specific": [
        "flag", "flags", "flag.txt", "secret", "secrets",
        "hidden", "private", "confidential", "restricted",
        "api/flag", "api/secret", "api/hidden",
        "api/v1/flag", "api/v1/secret",
        "getflag", "get_flag", "readflag", "read_flag",
        "submit", "submit_flag", "challenge", "challenges",
        "hint", "hints", "score", "scoreboard",
        "solve", "solved", "solution",
    ],
    "files_backup": [
        "backup", "backups", "dump", "export", "download",
        "files", "file", "upload", "uploads", "media",
        "static", "assets", "resources", "public",
        "storage", "data", "db", "database",
        "backup.sql", "backup.zip", "dump.sql",
        "database.sql", "data.json", "data.xml",
        ".git", ".git/config", ".git/HEAD",
        ".env", ".env.bak", ".env.local", ".env.production",
        "config.json", "config.yaml", "config.yml",
        "config.xml", "config.ini", "config.php",
        "settings.json", "settings.yaml", "settings.py",
        "package.json", "composer.json", "Gemfile",
        "requirements.txt", "Dockerfile", "docker-compose.yml",
        ".htaccess", ".htpasswd", "web.config",
        "robots.txt", "sitemap.xml", "crossdomain.xml",
        "security.txt", ".well-known/security.txt",
        "swagger.json", "swagger.yaml", "openapi.json",
        "openapi.yaml", "api-docs", "api/docs", "docs",
        "api/swagger", "api/openapi", "api/spec",
    ],
    "info_disclosure": [
        "status", "health", "healthcheck", "health-check",
        "ping", "pong", "alive", "ready", "version",
        "info", "information", "about", "metadata",
        "api/status", "api/health", "api/version", "api/info",
        "api/v1/status", "api/v1/health", "api/v1/info",
        "server-status", "server-info",
        "metrics", "prometheus", "monitoring",
        "actuator", "actuator/health", "actuator/info",
        "actuator/env", "actuator/beans", "actuator/mappings",
        "actuator/configprops", "actuator/trace",
        "env", "environment", "config", "configuration",
        "phpinfo", "phpinfo.php", "info.php", "test.php",
        "elmah.axd", "trace.axd",
        ".well-known", "manifest.json",
    ],
    "crud_resources": [
        "posts", "post", "articles", "article",
        "comments", "comment", "reviews", "review",
        "products", "product", "items", "item",
        "orders", "order", "carts", "cart",
        "messages", "message", "notifications", "notification",
        "tasks", "task", "jobs", "job",
        "notes", "note", "todos", "todo",
        "categories", "category", "tags", "tag",
        "groups", "group", "roles", "role", "permissions",
        "logs", "log", "events", "event", "audit",
        "reports", "report", "analytics", "stats", "statistics",
        "search", "query", "filter", "find", "lookup",
    ],
    "dangerous_actions": [
        "exec", "execute", "run", "eval", "system",
        "cmd", "command", "shell", "terminal",
        "api/exec", "api/run", "api/eval", "api/cmd",
        "debug/exec", "admin/exec", "admin/cmd",
        "render", "template", "preview",
        "import", "export", "migrate",
        "reset", "wipe", "delete", "destroy", "purge",
        "install", "setup", "init", "initialize",
        "proxy", "redirect", "forward", "fetch", "request",
        "ssrf", "callback", "webhook", "hook", "hooks",
    ],
    "numeric_ids": [
        "api/v1/users/1", "api/v1/users/2", "api/v1/users/0",
        "api/v1/users/100", "api/v1/users/admin",
        "api/users/1", "api/users/2", "api/users/0",
        "posts/1", "posts/2", "items/1", "items/2",
        "api/v1/posts/1", "api/v1/items/1",
        "orders/1", "messages/1", "notes/1",
    ],
}

HTTP_METHODS = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD", "TRACE"]

FRAMEWORK_SIGNATURES = {
    "Flask/Werkzeug": [
        ("server", "werkzeug"), ("server", "flask"),
        ("x-powered-by", "flask"),
    ],
    "Express.js": [
        ("x-powered-by", "express"),
    ],
    "Django": [
        ("server", "django"), ("x-frame-options", "deny"),
        ("x-content-type-options", "nosniff"),
    ],
    "Spring Boot": [
        ("x-application-context", ""), ("server", "apache-coyote"),
    ],
    "ASP.NET": [
        ("x-powered-by", "asp.net"), ("x-aspnet-version", ""),
        ("server", "microsoft-iis"),
    ],
    "PHP": [
        ("x-powered-by", "php"), ("server", "apache"),
    ],
    "Ruby on Rails": [
        ("x-powered-by", "phusion passenger"),
        ("x-runtime", ""), ("x-request-id", ""),
    ],
    "FastAPI": [
        ("server", "uvicorn"),
    ],
    "Nginx": [
        ("server", "nginx"),
    ],
    "Go (net/http)": [
        ("content-type", "text/plain"), ("server", "go"),
    ],
}

WAF_SIGNATURES = {
    "Cloudflare": ["cf-ray", "cf-cache-status", "__cfduid"],
    "AWS WAF": ["x-amzn-requestid", "x-amz